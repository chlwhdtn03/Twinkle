package com.example.twinkle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Write extends AppCompatActivity implements View.OnClickListener {

    Button submit;
    EditText title;
    EditText subtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);
        title = findViewById(R.id.title);
        subtitle = findViewById(R.id.subtitle);
        submit = findViewById(R.id.submitbtn);
        submit.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

    }
}
